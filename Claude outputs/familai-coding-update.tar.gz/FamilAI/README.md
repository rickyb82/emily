# FamilAI — assistente AI di famiglia

Framework self-hosted stile "chatbot Claude" pensato per una famiglia: adulti e bambini con livelli di permesso diversi, più provider LLM (Claude, OpenAI, Gemini), tool (ricerca web, immagini, video, documenti), server MCP, progetti e condivisione fra membri, con accesso remoto sicuro (HTTPS + passkey).

## Architettura

```
Internet ──HTTPS──▶ Caddy (TLS automatico Let's Encrypt)
                      ├── /api/*, /files/*  ──▶ backend  (FastAPI, Python)
                      └── /*                ──▶ frontend (React/Vite servito da nginx)
backend ──▶ SQLite (./data/familai.db) · ./data/uploads · ./data/generated
        ──▶ sandbox (esecuzione codice isolata, rete interna senza internet)
        ──▶ API Anthropic / OpenAI / Gemini · Tavily/Brave · server MCP (stdio o HTTP)
```

- **backend/** — FastAPI. Auth (password + passkey WebAuthn per gli adulti, PIN su dispositivi approvati per i bambini), policy per fascia d'età, agent loop con tool calling unificato per i tre provider, client MCP, progetti, condivisioni, log di utilizzo e audit.
- **frontend/** — Webapp React (login, passkey, PIN bambini, chat in streaming, progetti, condivisione, pannello famiglia).
- **Caddyfile / docker-compose.yml** — deploy su Ubuntu con un solo comando.

## Sicurezza (riassunto)

| Aspetto | Come |
|---|---|
| Trasporto | Solo HTTPS via Caddy, HSTS, header di sicurezza |
| Adulti | Email + password (Argon2) **e** passkey WebAuthn obbligatoria come secondo fattore (`REQUIRE_MFA_FOR_ADULTS`), codici di recupero monouso |
| Bambini | Login con avatar + PIN, **solo** da dispositivi approvati da un genitore (cookie di fiducia revocabile) |
| Sessioni | Cookie opaco HttpOnly + Secure + SameSite=Strict, header anti-CSRF, scadenza diversa adulti/bambini, revoca sessioni |
| Brute force | Rate limit su login/PIN, blocco account 15 min dopo 5 errori |
| Controllo genitori | Strumenti/provider consentiti, quote giornaliere (messaggi/immagini/video), fasce orarie, filtro contenuti (blocklist + OpenAI Moderation), supervisione conversazioni, messaggi segnalati, audit log |

## Avvio in produzione (Ubuntu + Docker)

1. Prerequisiti: Docker + Docker Compose; un dominio (es. `familai.tuodominio.it`) che punti all'IP pubblico di casa; porte **80 e 443** inoltrate dal router alla macchina Ubuntu.
2. Configura:
   ```bash
   cp .env.example .env
   nano .env        # PUBLIC_HOST, ACME_EMAIL, SECRET_KEY, WEBAUTHN_*, ADMIN_*, chiavi API
   ```
   `SECRET_KEY`: `openssl rand -hex 32`. `WEBAUTHN_RP_ID` = dominio, `WEBAUTHN_ORIGIN` = `https://dominio`.
3. Avvia:
   ```bash
   docker compose up -d --build
   docker compose logs -f backend
   ```
4. Apri `https://<PUBLIC_HOST>`, entra con `ADMIN_EMAIL`/`ADMIN_PASSWORD`, registra subito la **passkey** e salva i codici di recupero, poi cambia la password nelle Impostazioni.
5. In **Famiglia → Membri** crea gli altri adulti e i bambini (PIN + fascia d'età). Sul tablet/PC di casa, un adulto va in **Impostazioni → Dispositivo per i bambini → Approva**: da lì i bambini vedranno la schermata con gli avatar.

> WebAuthn funziona solo su origin sicuro: `https://` con un vero dominio (oppure `http://localhost` in sviluppo). Non funziona su `http://192.168.x.x`.

## Sviluppo locale (senza Docker)

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example ../.env   # e imposta COOKIE_SECURE=false, WEBAUTHN_RP_ID=localhost, WEBAUTHN_ORIGIN=http://localhost:5173
ENABLE_MOCK_PROVIDER=true uvicorn app.main:app --reload --env-file ../.env

# frontend (altra shell)
cd frontend
npm install
npm run dev     # http://localhost:5173 (proxy verso :8000)
```

Senza chiavi API il backend espone un provider `mock` per provare l'interfaccia (scrivi `cerca: qualcosa` o `disegna: un gatto` per vedere il ciclo dei tool).

API docs: `http://localhost:8000/api/docs`.

## Configurazione

### Provider e modelli
Le chiavi si inseriscono da **Famiglia → Provider AI** (salvate cifrate nel DB con `SECRET_KEY`, applicate a caldo, con pulsante "Prova connessione") oppure nel `.env` (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `*_DEFAULT_MODEL`); il pannello ha la precedenza sul file. Attenzione: se cambi `SECRET_KEY` le chiavi salvate dal pannello non sono più leggibili e vanno reinserite.

- **Bambini**: il genitore fissa provider e modello nella scheda del membro (Permessi → Provider AI / Modello); il bambino non vede il selettore.
- **Adulti**: scelgono provider e modello chat per chat dal menu in alto. Cambiando modello in una chat esistente viene proposto di **rigenerare l'ultima risposta** con il nuovo modello (`POST /chat/conversations/{id}/regenerate`); in ogni caso la cronologia viene convertita nel formato del nuovo provider e passata ai messaggi successivi. Il pulsante "↻ Rigenera risposta" è sempre disponibile.

### Tool
- **web_search**: Tavily (`TAVILY_API_KEY`) o Brave (`BRAVE_API_KEY`); fallback DuckDuckGo limitato. Ricerca sicura forzata per i bambini.
- **generate_image**: OpenAI `IMAGE_MODEL` (gpt-image-1). Per i bambini il prompt viene prefissato con vincoli "adatto ai bambini".
- **generate_video**: Gemini/Veo `VIDEO_MODEL`.
- **read_document**: PDF, DOCX, XLSX, testo; i documenti piccoli vengono inseriti direttamente nel contesto.

### Coding, artifact e anteprime
- **Artifact** (`create_artifact` / `update_artifact`): pagine e app HTML/CSS/JS, SVG, diagrammi Mermaid, markdown e programmi completi vengono creati in un pannello laterale con schede *Anteprima* e *Codice*, versioni, modifica manuale, download e apertura in nuova scheda. L'anteprima gira in un `<iframe sandbox>` senza `allow-same-origin`, quindi il codice generato non può leggere cookie né chiamare le API di FamilAI; l'endpoint `/api/artifacts/{id}/raw` aggiunge una CSP `sandbox`.
- **Esecuzione codice** (`run_code`): Python (numpy, pandas, matplotlib, pillow, sympy, scipy), JavaScript/TypeScript (Node 22), Java (JDK) e Bash girano nel servizio **`sandbox`** del compose: container separato, utente non root, filesystem read-only con tmpfs, `cap_drop: ALL`, limiti CPU/RAM/PID, timeout per esecuzione e **rete interna senza internet** (`sandbox_net: internal`). Output e file prodotti (grafici, CSV, immagini) tornano in chat come allegati. Il modello può passare file della chat/progetto alla sandbox (`file_ids`).
- Permessi: voci "Artifact" e "Esecuzione codice" nella policy. Default: 5–8 anni solo artifact, dai 9 anni anche esecuzione, adulti tutto.
- Non ancora supportato: avviare server web (Flask, Streamlit, Spring…) dentro la sandbox ed esporli in anteprima. È la naturale fase successiva (proxy verso una porta della sandbox per conversazione).

### RAG — ricerca nei documenti
Ogni documento caricato in un progetto (o allegato a una chat) viene estratto, spezzato in frammenti (`RAG_CHUNK_CHARS`) e indicizzato in background nella tabella `chunks`:
- con `OPENAI_API_KEY` o `GEMINI_API_KEY` i frammenti ricevono un **embedding** (`EMBEDDING_PROVIDER=auto|openai|gemini`) e la ricerca è **ibrida** (similarità coseno + BM25);
- senza chiavi la ricerca è solo per parole chiave (BM25), comunque utile.

A ogni messaggio l'assistente riceve automaticamente i `RAG_TOP_K` passaggi più pertinenti (evento `rag` nello stream, mostrato in chat) e dispone del tool `search_documents` per ricerche mirate; i documenti sotto `RAG_INLINE_MAX_CHARS` vengono comunque inseriti per intero. Nella pagina del progetto si vede lo stato dell'indice per file e si può **reindicizzare** (utile dopo aver aggiunto una chiave di embedding). Il permesso è lo stesso di "Documenti" nella policy dell'utente.

### Server MCP (`mcp_servers.json`)
```json
{ "servers": { "nome": { "enabled": true, "type": "stdio", "command": "npx", "args": ["-y", "pacchetto"], "min_role": "adult" } } }
```
`type` = `stdio` (processo nel container backend) o `http` (Streamable HTTP). `min_role` limita chi può usarli (`child`/`adult`/`admin`). I tool appaiono come `mcp__nome__tool` e sono abilitati dalla voce "Server MCP" nella policy dell'utente. Riavviare il backend dopo le modifiche.

### Policy per fascia d'età
Default in `backend/app/policy/permissions.py` (`DEFAULTS` e `SYSTEM_PROMPTS`), sovrascrivibili per singolo utente dal pannello Famiglia (strumenti, provider, quote, orari, filtro, parole bloccate, istruzioni personalizzate).

## Struttura dati principale
`families` · `users` (ruolo, fascia, policy JSON) · `webauthn_credentials` · `sessions` · `trusted_devices` · `projects` · `conversations` · `messages` (blocchi JSON: text/image/tool_use/tool_result) · `files` · `chunks` (RAG) · `artifacts` · `app_settings` · `shares` · `usage_log` · `audit_log`.

## Roadmap / idee
- Passkey come **unico** fattore (login senza password) e supporto a più famiglie.
- Vector store dedicato (pgvector/sqlite-vec) se i progetti crescono molto; re-ranking.
- Notifiche push ai genitori per messaggi segnalati.
- Voce (STT/TTS) per i più piccoli.
- Migrazioni DB con Alembic; backup automatico di `./data`.
