import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select

from .api import admin, auth, chat, files, projects, shares
from .config import get_settings
from .db import SessionLocal, init_db
from .models import AgeGroup, Family, Role, User
from .security.passwords import hash_secret
from .services import settings_store
from .tools.mcp_client import mcp_manager

settings = get_settings()
logging.basicConfig(level=settings.log_level.upper())
log = logging.getLogger("familai")


async def bootstrap_admin() -> None:
    async with SessionLocal() as db:
        if (await db.execute(select(User.id).limit(1))).scalar_one_or_none():
            return
        fam = Family(name=settings.family_name)
        db.add(fam)
        await db.flush()
        db.add(User(family_id=fam.id, email=settings.admin_email.lower(), username="admin",
                    display_name=settings.admin_name, avatar="👨‍💻", role=Role.admin, age_group=AgeGroup.adult,
                    password_hash=hash_secret(settings.admin_password)))
        await db.commit()
        log.warning("Creato amministratore iniziale %s — cambia la password e registra una passkey!", settings.admin_email)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await bootstrap_admin()
    async with SessionLocal() as db:
        await settings_store.apply(db)   # chiavi/modelli salvati dal pannello admin
    await mcp_manager.start()
    yield
    await mcp_manager.stop()


app = FastAPI(title="FamilAI", version="0.1.0", lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json")

if not settings.cookie_secure:  # solo sviluppo: frontend Vite su un'altra porta
    app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True,
                       allow_methods=["*"], allow_headers=["*"])

for r in (auth.router, chat.router, projects.router, shares.router, admin.router):
    app.include_router(r, prefix="/api")
app.include_router(files.router, prefix="/api")   # /api/files (upload/lista)
app.include_router(files.router)                  # /files/{id} (download inline, dietro Caddy)


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": app.version}
